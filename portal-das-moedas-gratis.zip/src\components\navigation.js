// Portal das Moedas - Navegação
export function initNavigation() {
  // Menu mobile toggle
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.getElementById('nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Fechar menu ao clicar em link
    navMenu.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }

  // Carrinho toggle
  const cartBtn = document.querySelector('.btn-cart');
  const cartClose = document.querySelector('.cart-close');
  const cartOverlay = document.getElementById('cart-overlay');

  cartBtn?.addEventListener('click', () => {
    document.getElementById('cart-sidebar')?.classList.add('open');
    cartOverlay?.classList.add('open');
    document.body.style.overflow = 'hidden';
  });

  cartClose?.addEventListener('click', closeCart);
  cartOverlay?.addEventListener('click', closeCart);

  // Busca no header
  const searchBtn = document.querySelector('.btn-search');
  searchBtn?.addEventListener('click', () => {
    window.location.href = '/busca.html';
  });

  // Fechar menus com ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeCart();
      navMenu?.classList.remove('open');
      navToggle?.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  });
}

export function closeCart() {
  document.getElementById('cart-sidebar')?.classList.remove('open');
  document.getElementById('cart-overlay')?.classList.remove('open');
  document.body.style.overflow = '';
}