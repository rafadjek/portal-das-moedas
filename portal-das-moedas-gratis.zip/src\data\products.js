// Portal das Moedas - Catálogo de Produtos
// IMPORTAÇÃO: Substitua este array pelos seus produtos reais do Shopee
// Use: npm run import:shopee (script separado) ou edite manualmente

export const categories = [
  { id: 'moedas', name: 'Moedas', icon: '🪙', description: 'Moedas antigas, comemorativas e de circulação' },
  { id: 'cedulas', name: 'Cédulas', icon: '💵', description: 'Cédulas antigas, raras e de colecionador' },
  { id: 'acessorios', name: 'Acessórios', icon: '🔧', description: 'Álbuns, lupas, estojos e materiais de conservação' },
  { id: 'kits', name: 'Kits e Lotes', icon: '📦', description: 'Kits completos e lotes especiais para colecionadores' }
];

// EXEMPLOS DE PRODUTOS - SUBSTITUA PELOS SEUS PRODUTOS REAIS DO SHOPEE
export const products = [
  {
    id: 'moeda-1',
    name: 'Moeda 1 Real 1994 - Plano Real - Flor de Cunho',
    category: 'moedas',
    price: 45.90,
    originalPrice: 59.90,
    images: [
      'assets/images/products/moeda-1-frente.svg',
      'assets/images/products/moeda-1-verso.svg'
    ],
    description: 'Moeda de 1 Real do ano de 1994, lançamento do Plano Real. Estado de conservação Flor de Cunho (FC), brilho original de cunhagem. Peça essencial para coleção do Plano Real.',
    details: {
      'Ano': '1994',
      'Metal': 'Aço inoxidável',
      'Diâmetro': '27mm',
      'Peso': '7,00g',
      'Estado': 'Flor de Cunho (FC)',
      'Cunhagem': 'Comum'
    },
    tags: ['Plano Real', '1 Real', '1994', 'FC', 'Brilho Original'],
    stock: 5,
    featured: true,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  },
  {
    id: 'moeda-2',
    name: 'Moeda 50 Centavos 1994 - Plano Real - MBC',
    category: 'moedas',
    price: 28.50,
    originalPrice: null,
    images: [
      'assets/images/products/moeda-2.svg'
    ],
    description: 'Moeda de 50 Centavos de 1994, primeira cunhagem do Plano Real. Estado Muito Bem Conservada (MBC), com detalhes nítidos.',
    details: {
      'Ano': '1994',
      'Metal': 'Bronze-alumínio',
      'Diâmetro': '23mm',
      'Peso': '4,10g',
      'Estado': 'Muito Bem Conservada (MBC)',
      'Cunhagem': 'Comum'
    },
    tags: ['Plano Real', '50 Centavos', '1994', 'MBC'],
    stock: 12,
    featured: false,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  },
  {
    id: 'cedula-1',
    name: 'Cédula 100 Cruzeiros Reais 1993 - Série A - MBC',
    category: 'cedulas',
    price: 85.00,
    originalPrice: 110.00,
    images: [
      'assets/images/products/cedula-1-frente.svg',
      'assets/images/products/cedula-1-verso.svg'
    ],
    description: 'Cédula de 100 Cruzeiros Reais de 1993, Série A. Estado Muito Bem Conservada (MBC), cores vivas, sem rasgos ou furos. Período de transição para o Plano Real.',
    details: {
      'Ano': '1993',
      'Valor': '100 Cruzeiros Reais',
      'Série': 'A',
      'Estado': 'Muito Bem Conservada (MBC)',
      'Dimensões': '140 x 65 mm',
      'Assinaturas': 'Gustavo Franco / Pedro Malan'
    },
    tags: ['Cruzeiros Reais', '1993', 'Transição', 'MBC', 'Plano Real'],
    stock: 3,
    featured: true,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  },
  {
    id: 'cedula-2',
    name: 'Cédula 10 Cruzeiros 1981 - República - Flor de Estampa',
    category: 'cedulas',
    price: 120.00,
    originalPrice: null,
    images: [
      'assets/images/products/cedula-2.svg'
    ],
    description: 'Cédula de 10 Cruzeiros de 1981, período da República. Estado Flor de Estampa (FE), perfeita, sem qualquer marca de manuseio. Peça rara neste estado.',
    details: {
      'Ano': '1981',
      'Valor': '10 Cruzeiros',
      'Período': 'República',
      'Estado': 'Flor de Estampa (FE)',
      'Dimensões': '154 x 74 mm',
      'Raridade': 'Rara em FE'
    },
    tags: ['Cruzeiros', '1981', 'República', 'FE', 'Rara'],
    stock: 1,
    featured: true,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  },
  {
    id: 'acessorio-1',
    name: 'Álbum para Moedas - 120 Bolsos - Couro Sintético',
    category: 'acessorios',
    price: 65.90,
    originalPrice: 89.90,
    images: [
      'assets/images/products/acessorio-1.svg'
    ],
    description: 'Álbum profissional para moedas com 120 bolsos transparentes (60 páginas, 2 bolsos por página). Capa em couro sintético premium, costura reforçada. Ideal para moedas de 1 centavo a 1 Real.',
    details: {
      'Capacidade': '120 moedas',
      'Bolsos por página': '2',
      'Total de páginas': '60',
      'Material da capa': 'Couro sintético premium',
      'Tamanho dos bolsos': 'Acomoda até 30mm',
      'Cor': 'Preto com detalhes dourados'
    },
    tags: ['Álbum', '120 bolsos', 'Couro', 'Organização', 'Proteção'],
    stock: 20,
    featured: false,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  },
  {
    id: 'acessorio-2',
    name: 'Lupa de Bolso 30x - Iluminação LED - Para Numismática',
    category: 'acessorios',
    price: 42.90,
    originalPrice: null,
    images: [
      'assets/images/products/acessorio-2.svg'
    ],
    description: 'Lupa de bolso com aumento 30x e iluminação LED embutida (3 LEDs brancos). Ideal para examinar detalhes de moedas, cédulas, marcas d\'água e microletras. Funciona com 3 baterias LR41 (inclusas).',
    details: {
      'Aumento': '30x',
      'Iluminação': '3 LEDs brancos',
      'Alimentação': '3x LR41 (inclusas)',
      'Diâmetro da lente': '21mm',
      'Material': 'ABS + lente acrílica',
      'Dimensões': '65 x 40 x 25mm'
    },
    tags: ['Lupa', '30x', 'LED', 'Exame', 'Detalhes'],
    stock: 15,
    featured: false,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  },
  {
    id: 'kit-1',
    name: 'Kit Iniciante Numismática - 20 Moedas + Álbum + Lupa',
    category: 'kits',
    price: 189.90,
    originalPrice: 259.90,
    images: [
      'assets/images/products/kit-1.svg'
    ],
    description: 'Kit completo para começar sua coleção: 20 moedas variadas (Brasil Império, República, Plano Real), álbum 60 bolsos e lupa 10x. Economia de 27% comprando o kit.',
    details: {
      'Moedas incluídas': '20 peças variadas',
      'Períodos': 'Império, República, Plano Real',
      'Álbum': '60 bolsos (30 páginas)',
      'Lupa': '10x aumento',
      'Economia': '27% vs compra individual'
    },
    tags: ['Kit', 'Iniciante', 'Completo', 'Economia', 'Presente'],
    stock: 8,
    featured: true,
    shopeeUrl: 'https://shopee.com.br/shop/486896133'
  }
];

// Função para buscar produtos por categoria
export function getProductsByCategory(categoryId) {
  if (categoryId === 'todos') return products;
  return products.filter(p => p.category === categoryId);
}

// Função para buscar produto por ID
export function getProductById(id) {
  return products.find(p => p.id === id);
}

// Função para buscar produtos em destaque
export function getFeaturedProducts() {
  return products.filter(p => p.featured);
}

// Função de busca
export function searchProducts(query) {
  const q = query.toLowerCase();
  return products.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.description.toLowerCase().includes(q) ||
    p.tags.some(tag => tag.toLowerCase().includes(q))
  );
}

// Função para formatar preço
export function formatPrice(price) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(price);
}