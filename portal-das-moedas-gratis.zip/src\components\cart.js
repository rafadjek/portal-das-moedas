// Portal das Moedas - Carrinho (funcionalidades já estão no app.js)
// Este arquivo existe para modularidade futura
export function initCart() {
  // Carrinho já inicializado no app.js
  // Aqui podemos adicionar funcionalidades extras futuramente
  console.log('Carrinho inicializado');
}