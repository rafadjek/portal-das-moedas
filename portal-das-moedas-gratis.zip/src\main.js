// Portal das Moedas - Entry Point Principal
import { initApp } from './app.js';
import { initCart } from './components/cart.js';
import { initNavigation } from './components/navigation.js';

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', async () => {
  // Inicializar módulos
  initNavigation();
  initCart();
  initApp();

  // Marcar link ativo na navegação
  setActiveNavLink();
});

function setActiveNavLink() {
  const path = window.location.pathname;
  const links = document.querySelectorAll('.nav-link');
  links.forEach(link => {
    const href = link.getAttribute('href');
    if (href === path || (path === '/' && href === '/')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

// Exportar para uso global
window.PortalDasMoedas = {
  formatPrice: (price) => new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(price)
};