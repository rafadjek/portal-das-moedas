// Portal das Moedas - App Core
import { products, categories, getProductsByCategory, getProductById, getFeaturedProducts, searchProducts, formatPrice } from '../data/products.js';

// Estado global da aplicação
export const state = {
  products: [],
  categories: [],
  cart: [],
  currentPage: 'home',
  searchQuery: '',
  selectedCategory: 'todos'
};

// Inicializar app
export function initApp() {
  state.products = products;
  state.categories = categories;

  // Inicializar carrinho do localStorage
  const savedCart = localStorage.getItem('portal-das-moedas-cart');
  if (savedCart) {
    try {
      state.cart = JSON.parse(savedCart);
      updateCartUI();
    } catch (e) {
      console.warn('Erro ao carregar carrinho:', e);
    }
  }

  // Detectar página atual e inicializar
  const path = window.location.pathname;
  if (path === '/' || path === '/index.html') {
    initHomePage();
  } else if (path.includes('catalogo')) {
    initCatalogPage();
  } else if (path.includes('produto')) {
    initProductPage();
  } else if (path.includes('checkout')) {
    initCheckoutPage();
  } else if (path.includes('busca')) {
    initSearchPage();
  }
}

// ==================== HOME PAGE ====================
function initHomePage() {
  renderFeaturedProducts();
  renderCategories();
}

function renderFeaturedProducts() {
  const container = document.getElementById('featured-products');
  if (!container) return;

  const featured = getFeaturedProducts().slice(0, 8);
  container.innerHTML = featured.map(product => createProductCard(product)).join('');
  attachProductCardEvents(container);
}

function renderCategories() {
  const container = document.getElementById('categories-grid');
  if (!container) return;

  container.innerHTML = categories.map(cat => `
    <a href="/catalogo.html?cat=${cat.id}" class="category-card">
      <div class="category-icon">${cat.icon}</div>
      <h3>${cat.name}</h3>
      <p>${cat.description}</p>
    </a>
  `).join('');
}

// ==================== CATALOG PAGE ====================
function initCatalogPage() {
  const urlParams = new URLSearchParams(window.location.search);
  state.selectedCategory = urlParams.get('cat') || 'todos';
  state.searchQuery = urlParams.get('q') || '';

  renderCategoryFilters();
  renderProductGrid();
  updatePageTitle();
}

function renderCategoryFilters() {
  const container = document.getElementById('category-filters');
  if (!container) return;

  const allCategories = ['todos', ...categories.map(c => c.id)];
  container.innerHTML = allCategories.map(catId => {
    const cat = categories.find(c => c.id === catId);
    const isActive = state.selectedCategory === catId;
    const label = catId === 'todos' ? 'Todos' : (cat?.name || catId);
    const icon = catId === 'todos' ? '🏪' : (cat?.icon || '📦');

    return `
      <button class="filter-btn ${isActive ? 'active' : ''}" data-category="${catId}">
        <span class="filter-icon">${icon}</span>
        <span>${label}</span>
      </button>
    `;
  }).join('');

  // Event listeners
  container.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedCategory = btn.dataset.category;
      updateURL();
      renderCategoryFilters();
      renderProductGrid();
    });
  });
}

function renderProductGrid() {
  const container = document.getElementById('product-grid');
  const countEl = document.getElementById('product-count');
  if (!container) return;

  let filteredProducts = getProductsByCategory(state.selectedCategory);

  if (state.searchQuery) {
    filteredProducts = filteredProducts.filter(p =>
      p.name.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      p.tags.some(tag => tag.toLowerCase().includes(state.searchQuery.toLowerCase()))
    );
  }

  if (countEl) {
    countEl.textContent = `${filteredProducts.length} produto${filteredProducts.length !== 1 ? 's' : ''} encontrado${filteredProducts.length !== 1 ? 's' : ''}`;
  }

  if (filteredProducts.length === 0) {
    container.innerHTML = `
      <div class="no-products">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
          <circle cx="11" cy="11" r="8"/>
          <path d="M21 21l-4.35-4.35"/>
        </svg>
        <h3>Nenhum produto encontrado</h3>
        <p>Tente ajustar seus filtros ou busca</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filteredProducts.map(product => createProductCard(product)).join('');
  attachProductCardEvents(container);
}

function updatePageTitle() {
  const titleEl = document.getElementById('page-title');
  if (!titleEl) return;

  if (state.selectedCategory === 'todos') {
    titleEl.textContent = 'Todos os Produtos';
  } else {
    const cat = categories.find(c => c.id === state.selectedCategory);
    titleEl.textContent = cat?.name || 'Produtos';
  }
}

function updateURL() {
  const params = new URLSearchParams();
  if (state.selectedCategory !== 'todos') params.set('cat', state.selectedCategory);
  if (state.searchQuery) params.set('q', state.searchQuery);
  const newURL = `${window.location.pathname}${params.toString() ? '?' + params.toString() : ''}`;
  window.history.replaceState({}, '', newURL);
}

// ==================== PRODUCT PAGE ====================
function initProductPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  if (!productId) {
    window.location.href = '/catalogo.html';
    return;
  }

  const product = getProductById(productId);
  if (!product) {
    window.location.href = '/catalogo.html';
    return;
  }

  renderProductDetail(product);
  initImageGallery(product);
  initQuantitySelector();
  initAddToCart(product);
}

function renderProductDetail(product) {
  // Atualizar meta tags
  document.title = `${product.name} - Portal das Moedas`;
  updateMetaTags(product);

  // Breadcrumb
  const breadcrumb = document.getElementById('breadcrumb');
  if (breadcrumb) {
    const cat = categories.find(c => c.id === product.category);
    breadcrumb.innerHTML = `
      <a href="/">Início</a>
      <span>/</span>
      <a href="/catalogo.html?cat=${product.category}">${cat?.name || product.category}</a>
      <span>/</span>
      <span>${product.name}</span>
    `;
  }

  // Galeria de imagens
  const mainImage = document.getElementById('main-image');
  const thumbnails = document.getElementById('thumbnails');
  if (mainImage && thumbnails) {
    mainImage.src = product.images[0];
    mainImage.alt = product.name;
    thumbnails.innerHTML = product.images.map((img, i) => `
      <button class="thumbnail ${i === 0 ? 'active' : ''}" data-index="${i}" aria-label="Imagem ${i + 1}">
        <img src="${img}" alt="${product.name} - visão ${i + 1}">
      </button>
    `).join('');
  }

  // Info do produto
  const nameEl = document.getElementById('product-name');
  const priceEl = document.getElementById('product-price');
  const descEl = document.getElementById('product-description');
  const tagsEl = document.getElementById('product-tags');
  const stockEl = document.getElementById('product-stock');

  if (nameEl) nameEl.textContent = product.name;
  if (priceEl) priceEl.innerHTML = `
    <span class="price-current">${formatPrice(product.price)}</span>
    ${product.originalPrice ? `<span class="price-original">${formatPrice(product.originalPrice)}</span>` : ''}
    ${product.originalPrice ? `<span class="badge badge-sale">${Math.round((1 - product.price / product.originalPrice) * 100)}% OFF</span>` : ''}
  `;
  if (descEl) descEl.textContent = product.description;
  if (tagsEl) {
    tagsEl.innerHTML = product.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
  }
  if (stockEl) {
    const inStock = product.stock > 0;
    stockEl.innerHTML = `
      <span class="stock-status ${inStock ? 'in-stock' : 'out-of-stock'}">
        ${inStock ? `✓ ${product.stock} em estoque` : '✗ Fora de estoque'}
      </span>
    `;
  }

  // Detalhes técnicos
  const detailsEl = document.getElementById('product-details');
  if (detailsEl && product.details) {
    detailsEl.innerHTML = Object.entries(product.details).map(([key, value]) => `
      <div class="detail-row">
        <span class="detail-label">${key}</span>
        <span class="detail-value">${value}</span>
      </div>
    `).join('');
  }

  // Produtos relacionados
  renderRelatedProducts(product);
}

function updateMetaTags(product) {
  const ogTitle = document.querySelector('meta[property="og:title"]');
  const ogDesc = document.querySelector('meta[property="og:description"]');
  const ogImage = document.querySelector('meta[property="og:image"]');

  if (ogTitle) ogTitle.setAttribute('content', product.name);
  if (ogDesc) ogDesc.setAttribute('content', product.description.substring(0, 160));
  if (ogImage && product.images[0]) ogImage.setAttribute('content', product.images[0]);
}

function initImageGallery(product) {
  const thumbnails = document.getElementById('thumbnails');
  const mainImage = document.getElementById('main-image');
  if (!thumbnails || !mainImage) return;

  thumbnails.addEventListener('click', (e) => {
    const btn = e.target.closest('.thumbnail');
    if (!btn) return;

    const index = parseInt(btn.dataset.index);
    mainImage.src = product.images[index];
    mainImage.alt = `${product.name} - visão ${index + 1}`;

    thumbnails.querySelectorAll('.thumbnail').forEach((t, i) => {
      t.classList.toggle('active', i === index);
    });
  });
}

function initQuantitySelector() {
  const qtyInput = document.getElementById('quantity');
  const minusBtn = document.getElementById('qty-minus');
  const plusBtn = document.getElementById('qty-plus');

  if (!qtyInput) return;

  minusBtn?.addEventListener('click', () => {
    const val = parseInt(qtyInput.value) || 1;
    if (val > 1) qtyInput.value = val - 1;
  });

  plusBtn?.addEventListener('click', () => {
    const val = parseInt(qtyInput.value) || 1;
    const max = parseInt(qtyInput.max) || 99;
    if (val < max) qtyInput.value = val + 1;
  });

  qtyInput.addEventListener('change', () => {
    let val = parseInt(qtyInput.value) || 1;
    const max = parseInt(qtyInput.max) || 99;
    if (val < 1) val = 1;
    if (val > max) val = max;
    qtyInput.value = val;
  });
}

function initAddToCart(product) {
  const btn = document.getElementById('add-to-cart');
  const buyNowBtn = document.getElementById('buy-now');
  if (!btn) return;

  const inStock = product.stock > 0;
  btn.disabled = !inStock;
  btn.textContent = inStock ? 'Adicionar ao Carrinho' : 'Fora de Estoque';

  btn.addEventListener('click', () => {
    const qtyInput = document.getElementById('quantity');
    const quantity = parseInt(qtyInput?.value) || 1;
    addToCart(product, quantity);
    openCart();
  });

  buyNowBtn?.addEventListener('click', () => {
    const qtyInput = document.getElementById('quantity');
    const quantity = parseInt(qtyInput?.value) || 1;
    addToCart(product, quantity);
    window.location.href = '/checkout.html';
  });
}

function renderRelatedProducts(currentProduct) {
  const container = document.getElementById('related-products');
  if (!container) return;

  const related = products
    .filter(p => p.id !== currentProduct.id && p.category === currentProduct.category)
    .slice(0, 4);

  if (related.length === 0) {
    container.closest('.related-section')?.style.display = 'none';
    return;
  }

  container.innerHTML = related.map(product => createProductCard(product)).join('');
  attachProductCardEvents(container);
}

// ==================== SEARCH PAGE ====================
function initSearchPage() {
  const urlParams = new URLSearchParams(window.location.search);
  state.searchQuery = urlParams.get('q') || '';

  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.value = state.searchQuery;
    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') performSearch(searchInput.value);
    });
  }

  const searchBtn = document.getElementById('search-btn');
  searchBtn?.addEventListener('click', () => performSearch(searchInput?.value || ''));

  if (state.searchQuery) {
    performSearch(state.searchQuery);
  }
}

function performSearch(query) {
  state.searchQuery = query.trim();
  const params = new URLSearchParams();
  if (state.searchQuery) params.set('q', state.searchQuery);
  window.location.href = `/busca.html${params.toString() ? '?' + params.toString() : ''}`;
}

// ==================== CHECKOUT PAGE ====================
function initCheckoutPage() {
  if (state.cart.length === 0) {
    window.location.href = '/catalogo.html';
    return;
  }

  renderCheckoutItems();
  initCheckoutForm();
}

function renderCheckoutItems() {
  const container = document.getElementById('checkout-items');
  const subtotalEl = document.getElementById('checkout-subtotal');
  const shippingEl = document.getElementById('checkout-shipping');
  const totalEl = document.getElementById('checkout-total');

  if (!container) return;

  container.innerHTML = state.cart.map(item => `
    <div class="checkout-item">
      <img src="${item.images[0]}" alt="${item.name}" class="checkout-item-image">
      <div class="checkout-item-info">
        <h4>${item.name}</h4>
        <p>${formatPrice(item.price)} x ${item.quantity}</p>
      </div>
      <span class="checkout-item-total">${formatPrice(item.price * item.quantity)}</span>
    </div>
  `).join('');

  const subtotal = state.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 299 ? 0 : 29.90; // Frete grátis acima de R$ 299
  const total = subtotal + shipping;

  if (subtotalEl) subtotalEl.textContent = formatPrice(subtotal);
  if (shippingEl) shippingEl.textContent = shipping === 0 ? 'Grátis' : formatPrice(shipping);
  if (totalEl) totalEl.textContent = formatPrice(total);
}

function initCheckoutForm() {
  const form = document.getElementById('checkout-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(form);
    const order = {
      items: state.cart,
      customer: {
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        number: formData.get('number'),
        complement: formData.get('complement'),
        neighborhood: formData.get('neighborhood'),
        city: formData.get('city'),
        state: formData.get('state'),
        zipcode: formData.get('zipcode')
      },
      payment: formData.get('payment'),
      notes: formData.get('notes'),
      createdAt: new Date().toISOString(),
      total: state.cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
    };

    // Simular envio do pedido
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="loading"></span> Processando...';

    await new Promise(resolve => setTimeout(resolve, 1500));

    // Limpar carrinho
    state.cart = [];
    saveCart();
    updateCartUI();

    // Redirecionar para sucesso
    window.location.href = `/sucesso.html?order=${Date.now()}`;
  });
}

// ==================== CART FUNCTIONS ====================
export function addToCart(product, quantity = 1) {
  const existingIndex = state.cart.findIndex(item => item.id === product.id);

  if (existingIndex >= 0) {
    const newQty = state.cart[existingIndex].quantity + quantity;
    if (newQty <= product.stock) {
      state.cart[existingIndex].quantity = newQty;
    } else {
      showToast(`Estoque máximo: ${product.stock} unidades`, 'warning');
      return;
    }
  } else {
    if (quantity <= product.stock) {
      state.cart.push({ ...product, quantity });
    } else {
      showToast(`Estoque máximo: ${product.stock} unidades`, 'warning');
      return;
    }
  }

  saveCart();
  updateCartUI();
  showToast(`${product.name} adicionado ao carrinho!`, 'success');
}

export function removeFromCart(productId) {
  state.cart = state.cart.filter(item => item.id !== productId);
  saveCart();
  updateCartUI();
}

export function updateCartQuantity(productId, quantity) {
  const item = state.cart.find(item => item.id === productId);
  if (!item) return;

  if (quantity <= 0) {
    removeFromCart(productId);
  } else if (quantity <= item.stock) {
    item.quantity = quantity;
    saveCart();
    updateCartUI();
  } else {
    showToast(`Estoque máximo: ${item.stock} unidades`, 'warning');
  }
}

function saveCart() {
  localStorage.setItem('portal-das-moedas-cart', JSON.stringify(state.cart));
}

export function updateCartUI() {
  const countEl = document.querySelector('.cart-count');
  const cartItemsEl = document.getElementById('cart-items');
  const subtotalEl = document.getElementById('cart-subtotal');
  const totalEl = document.getElementById('cart-total');
  const emptyEl = document.getElementById('cart-empty');

  const totalItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = state.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (countEl) {
    countEl.textContent = totalItems;
    countEl.style.display = totalItems > 0 ? 'flex' : 'none';
  }

  if (cartItemsEl) {
    if (state.cart.length === 0) {
      cartItemsEl.innerHTML = '';
      emptyEl?.removeAttribute('hidden');
    } else {
      emptyEl?.setAttribute('hidden', '');
      cartItemsEl.innerHTML = state.cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
          <img src="${item.images[0]}" alt="${item.name}" class="cart-item-image">
          <div class="cart-item-details">
            <h4 class="cart-item-name">${item.name}</h4>
            <span class="cart-item-price">${formatPrice(item.price)}</span>
            <div class="cart-item-qty">
              <button class="qty-btn" data-action="decrease" aria-label="Diminuir quantidade">−</button>
              <span class="qty-value">${item.quantity}</span>
              <button class="qty-btn" data-action="increase" aria-label="Aumentar quantidade">+</button>
            </div>
          </div>
          <button class="cart-item-remove" aria-label="Remover ${item.name}">✕</button>
        </div>
      `).join('');

      // Event listeners para quantidade e remoção
      cartItemsEl.querySelectorAll('.qty-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const itemEl = btn.closest('.cart-item');
          const id = itemEl.dataset.id;
          const action = btn.dataset.action;
          const item = state.cart.find(i => i.id === id);
          if (item) {
            updateCartQuantity(id, action === 'increase' ? item.quantity + 1 : item.quantity - 1);
          }
        });
      });

      cartItemsEl.querySelectorAll('.cart-item-remove').forEach(btn => {
        btn.addEventListener('click', () => {
          const itemEl = btn.closest('.cart-item');
          removeFromCart(itemEl.dataset.id);
        });
      });
    }
  }

  if (subtotalEl) subtotalEl.textContent = formatPrice(subtotal);
  if (totalEl) totalEl.textContent = formatPrice(subtotal);
}

export function openCart() {
  document.getElementById('cart-sidebar')?.classList.add('open');
  document.getElementById('cart-overlay')?.classList.add('open');
  document.body.style.overflow = 'hidden';
}

export function closeCart() {
  document.getElementById('cart-sidebar')?.classList.remove('open');
  document.getElementById('cart-overlay')?.classList.remove('open');
  document.body.style.overflow = '';
}

// ==================== TOAST NOTIFICATIONS ====================
export function showToast(message, type = 'info') {
  const container = getOrCreateToastContainer();
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span>${message}</span>
    <button class="toast-close" aria-label="Fechar">&times;</button>
  `;

  container.appendChild(toast);

  // Animar entrada
  requestAnimationFrame(() => toast.classList.add('show'));

  // Auto remover
  setTimeout(() => removeToast(toast), 4000);

  // Botão fechar
  toast.querySelector('.toast-close').addEventListener('click', () => removeToast(toast));
}

function getOrCreateToastContainer() {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  return container;
}

function removeToast(toast) {
  toast.classList.remove('show');
  setTimeout(() => toast.remove(), 300);
}

// ==================== PRODUCT CARD ====================
function createProductCard(product) {
  const inStock = product.stock > 0;
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return `
    <article class="product-card" data-id="${product.id}">
      <div class="product-image">
        <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
        ${product.featured ? '<span class="badge badge-featured">Destaque</span>' : ''}
        ${hasDiscount ? `<span class="badge badge-sale">${Math.round((1 - product.price / product.originalPrice) * 100)}% OFF</span>` : ''}
        ${!inStock ? '<span class="badge badge-out">Esgotado</span>' : ''}
      </div>
      <div class="product-info">
        <span class="product-category">${categories.find(c => c.id === product.category)?.name || product.category}</span>
        <h3 class="product-name">${product.name}</h3>
        <div class="product-price">
          <span class="price-current">${formatPrice(product.price)}</span>
          ${hasDiscount ? `<span class="price-original">${formatPrice(product.originalPrice)}</span>` : ''}
        </div>
        <button class="btn btn-primary btn-block add-to-cart-btn" ${!inStock ? 'disabled' : ''} data-id="${product.id}">
          ${inStock ? 'Adicionar ao Carrinho' : 'Fora de Estoque'}
        </button>
      </div>
    </article>
  `;
}

function attachProductCardEvents(container) {
  container.querySelectorAll('.add-to-cart-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const productId = btn.dataset.id;
      const product = getProductById(productId);
      if (product) addToCart(product, 1);
    });
  });

  container.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('.add-to-cart-btn')) return;
      const productId = card.dataset.id;
      window.location.href = `/produto.html?id=${productId}`;
    });
  });
}

// ==================== UTILITÁRIOS ====================
export function debounce(fn, delay) {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
}

export function getCartTotal() {
  return state.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

export function getCartCount() {
  return state.cart.reduce((sum, item) => sum + item.quantity, 0);
}